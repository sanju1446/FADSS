require('dotenv').config();
const express = require('express');
const fs = require('fs');
const path = require('path');
const passport = require('passport');
const session = require('express-session');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const nodemailer = require("nodemailer");

const app = express();
const USERS_FILE = path.join(__dirname, 'users.json');

/* -----------------------------------------------------------
   EXPRESS + STATIC + SESSION
----------------------------------------------------------- */
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: process.env.SESSION_SECRET || 'dev_secret',
  resave: false,
  saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());

/* -----------------------------------------------------------
   READ + WRITE USERS TO JSON
----------------------------------------------------------- */
function readUsers(){
  if (!fs.existsSync(USERS_FILE)) return [];
  try { return JSON.parse(fs.readFileSync(USERS_FILE)); }
  catch { return []; }
}

function writeUsers(users){
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
}

/* -----------------------------------------------------------
   GOOGLE ACCOUNT DB HELPERS
----------------------------------------------------------- */
function findUserByProviderId(providerId){
  return readUsers().find(u => u.providerId === providerId);
}

function createUserFromGoogle(profile){
  const users = readUsers();

  const email = profile.emails?.[0]?.value || "";
  let username = email ? email.split("@")[0] : profile.displayName.replace(/\s+/g, "").toLowerCase();

  // ensure unique username
  let base = username;
  let num = 1;
  while (users.find(u => u.username === username)) {
    username = base + num;
    num++;
  }

  const newUser = {
    id: Date.now().toString(),
    username,
    email,
    provider: "google",
    providerId: profile.id
  };

  users.push(newUser);
  writeUsers(users);

  return newUser;
}

/* -----------------------------------------------------------
   PASSPORT (Google OAuth)
----------------------------------------------------------- */
passport.serializeUser((user, done) => {
  done(null, user.id);
});

passport.deserializeUser((id, done) => {
  const user = readUsers().find(u => u.id === id);
  done(null, user || false);
});

passport.use(new GoogleStrategy({
  clientID: process.env.GOOGLE_CLIENT_ID,
  clientSecret: process.env.GOOGLE_CLIENT_SECRET,
  callbackURL: `${process.env.BASE_URL}/auth/google/callback`
},
(accessToken, refreshToken, profile, done) => {
  let user = findUserByProviderId(profile.id);
  if (!user) user = createUserFromGoogle(profile);
  return done(null, user);
}));

/* -----------------------------------------------------------
   NORMAL SIGNUP
----------------------------------------------------------- */
app.post("/signup", (req, res) => {
  const { username, email, password } = req.body;

  if (!username || !email || !password)
    return res.json({ success: false, msg: "Please Enter Valid Details" });

  const users = readUsers();
  if (users.some(u => u.username === username || u.email === email))
    return res.json({ success: false, msg: "Username or Email already exists" });

  users.push({ id: Date.now().toString(), username, email, password });
  writeUsers(users);

  res.json({ success: true });
});

/* -----------------------------------------------------------
   NORMAL LOGIN
----------------------------------------------------------- */
app.post("/login", (req, res) => {
  const { username, password } = req.body;

  const users = readUsers();
  const valid = users.find(u => u.username === username && u.password === password);

  if (!valid) return res.json({ success:false });

  req.session.user = valid;
  res.json({ success:true });
});

/* -----------------------------------------------------------
   GOOGLE AUTH ROUTES
----------------------------------------------------------- */
app.get("/auth/google",
  passport.authenticate("google", { scope: ["profile", "email"] })
);

app.get("/auth/google/callback",
  passport.authenticate("google", { failureRedirect: "/login.html" }),
  (req, res) => {
    res.redirect("/auth/google/success");
  }
);

app.get("/auth/google/success", (req, res) => {
  if (!req.user) return res.redirect("/login.html");

  res.send(`
    <script>
      localStorage.setItem("fadss_logged_user", "${req.user.username}");
      window.location.href = "/dashboard.html";
    </script>
  `);
});

/* -----------------------------------------------------------
   NODEMAILER EMAIL SETUP (GMAIL APP PASSWORD)
----------------------------------------------------------- */
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,  // your Gmail
    pass: process.env.EMAIL_PASS   // 16-digit App Password
  }
});

function sendVerificationEmail(to, code) {
  return transporter.sendMail({
    from: `"FADSS Support" <${process.env.EMAIL_USER}>`,
    to,
    subject: "FADSS Password Reset Code",
    html: `
      <h2>Password Reset Code</h2>
      <p>Use the code below to reset your password:</p>
      <h1>${code}</h1>
      <p>Expires in 10 minutes.</p>
    `
  });
}

/* -----------------------------------------------------------
   FORGOT PASSWORD — SEND CODE
----------------------------------------------------------- */
app.post("/forgot-password", async (req, res) => {
  const { email } = req.body;
  const users = readUsers();
  const user = users.find(u => u.email === email);

  if (!user) return res.json({ success: false, msg: "Email not found" });

  const code = Math.floor(100000 + Math.random() * 900000).toString();

  user.resetCode = code;
  user.resetExpires = Date.now() + 10 * 60 * 1000; // 10 minutes
  writeUsers(users);

  await sendVerificationEmail(email, code);

  res.json({ success: true, msg: "Verification code sent!" });
});

/* -----------------------------------------------------------
   VERIFY RESET CODE
----------------------------------------------------------- */
app.post("/verify-reset-code", (req, res) => {
  const { email, code } = req.body;

  const users = readUsers();
  const user = users.find(u => u.email === email);

  if (!user) return res.json({ success: false, msg: "Email not found" });
  if (!user.resetCode) return res.json({ success: false, msg: "No reset request" });
  if (user.resetCode !== code) return res.json({ success: false, msg: "Invalid code" });
  if (Date.now() > user.resetExpires) return res.json({ success: false, msg: "Code expired" });

  res.json({ success: true });
});

/* -----------------------------------------------------------
   RESET PASSWORD
----------------------------------------------------------- */
app.post("/reset-password", (req, res) => {
  const { email, newPassword } = req.body;

  const users = readUsers();
  const user = users.find(u => u.email === email);

  if (!user) 
    return res.json({ success: false, msg: "Email not found" });

  if (!newPassword)
    return res.json({ success: false, msg: "Password missing" });

  user.password = newPassword;

  delete user.resetCode;
  delete user.resetExpires;

  writeUsers(users);

  res.json({ success: true });
});


/* -----------------------------------------------------------
   START SERVER
----------------------------------------------------------- */
app.listen(process.env.PORT, () =>
  console.log("Running at: http://localhost:3000/login.html")
);
