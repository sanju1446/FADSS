from fastapi import FastAPI
from pydantic import BaseModel
import numpy as np
import pickle
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# Allow frontend to access API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load the model
with open("crop_model.pkl", "rb") as f:
    model = pickle.load(f)

# The INPUT structure must match CSV features
class CropInput(BaseModel):
    N: float
    P: float
    K: float
    temperature: float
    humidity: float
    ph: float

@app.post("/predict")
def predict_crop(data: CropInput):
    input_data = np.array([[data.N, data.P, data.K,
                            data.temperature, data.humidity, data.ph]])

    prediction = model.predict(input_data)[0]

    return {"crop": prediction}
